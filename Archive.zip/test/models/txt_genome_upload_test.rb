require 'test_helper'

class TxtGenomeUploadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
