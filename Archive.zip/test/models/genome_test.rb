require 'test_helper'

class GenomeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
