module ReceiveHelper
end
