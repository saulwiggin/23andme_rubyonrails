module AnalysisHelper
end
