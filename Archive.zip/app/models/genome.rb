class Genome < ApplicationRecord
  has_attached_file :txtfile
end
