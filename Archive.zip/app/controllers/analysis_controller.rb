class AnalysisController < ApplicationController
  def nutrition

  end
end
